/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.reservationsystem;

/**
 *
 * @author RC_Student_lab
 */
import java.util.Scanner;

public class ReservationSystem {

    // Base class (Booking)
    static class Booking {
        private String date;
        private int tableNumber;

        public Booking(String date, int tableNumber) {
            this.date = date;
            this.tableNumber = tableNumber;
        }

        public String getDate() {
            return date;
        }

        public int getTableNumber() {
            return tableNumber;
        }
    }

    // Derived class (Reservation extends Booking)
    static class Reservation extends Booking {
        private String customerName;
        private int numberOfGuests;

        public Reservation(String date, int tableNumber, String customerName, int numberOfGuests) {
            super(date, tableNumber);
            this.customerName = customerName;
            this.numberOfGuests = numberOfGuests;
        }

        public String getCustomerName() {
            return customerName;
        }

        public int getNumberOfGuests() {
            return numberOfGuests;
        }

        @Override
        public String toString() {
            return "Reservation [Date: " + getDate() +
                   ", Table: " + getTableNumber() +
                   ", Customer: " + customerName +
                   ", Guests: " + numberOfGuests + "]";
        }
    }

    // Array for reservations
    private Reservation[] reservations = new Reservation[10];
    private int count = 0;

    // Add reservation
    private boolean addReservation(Reservation r) {
        if (count < reservations.length) {
            reservations[count] = r;
            count++;
            return true;
        }
        return false;
    }

    // Delete reservation
    private boolean deleteReservation(String customerName) {
        for (int i = 0; i < count; i++) {
            if (reservations[i].getCustomerName().equalsIgnoreCase(customerName)) {
                // Shift left
                for (int j = i; j < count - 1; j++) {
                    reservations[j] = reservations[j + 1];
                }
                reservations[count - 1] = null;
                count--;
                return true;
            }
        }
        return false;
    }

    // Display all reservations
    private void displayReservations() {
        if (count == 0) {
            System.out.println("No reservations found.");
        } else {
            System.out.println("\n--- Reservation List ---");
            for (int i = 0; i < count; i++) {
                System.out.println((i + 1) + ". " + reservations[i]);
            }
        }
    }

    // Search reservation by customer name
    private void searchByCustomer(String name) {
        boolean found = false;
        for (int i = 0; i < count; i++) {
            if (reservations[i].getCustomerName().equalsIgnoreCase(name)) {
                System.out.println("Found: " + reservations[i]);
                found = true;
            }
        }
        if (!found) {
            System.out.println("No reservation found for customer: " + name);
        }
    }

    // Search reservation by table number
    private void searchByTable(int table) {
        boolean found = false;
        for (int i = 0; i < count; i++) {
            if (reservations[i].getTableNumber() == table) {
                System.out.println("Found: " + reservations[i]);
                found = true;
            }
        }
        if (!found) {
            System.out.println("No reservation found for table: " + table);
        }
    }

    // Main program
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ReservationSystem system = new ReservationSystem();

        while (true) {
            System.out.println("\n--- Restaurant Reservation System ---");
            System.out.println("1. Add Reservation");
            System.out.println("2. Delete Reservation");
            System.out.println("3. View Reservations");
            System.out.println("4. Search Reservation");
            System.out.println("5. Exit");
            System.out.print("Choose option: ");
            int choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Enter Date (YYYY-MM-DD): ");
                    String date = sc.nextLine();
                    System.out.print("Enter Table Number: ");
                    int table = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter Customer Name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter Number of Guests: ");
                    int guests = sc.nextInt();
                    sc.nextLine();

                    Reservation r = new Reservation(date, table, name, guests);
                    if (system.addReservation(r)) {
                        System.out.println("Reservation added successfully!");
                    } else {
                        System.out.println("Reservation list is full.");
                    }
                    break;

                case 2:
                    System.out.print("Enter Customer Name to delete: ");
                    String delName = sc.nextLine();
                    if (system.deleteReservation(delName)) {
                        System.out.println("Reservation deleted successfully.");
                    } else {
                        System.out.println("Reservation not found.");
                    }
                    break;

                case 3:
                    system.displayReservations();
                    break;

                case 4:
                    System.out.println("Search by: ");
                    System.out.println("1. Customer Name");
                    System.out.println("2. Table Number");
                    int searchChoice = sc.nextInt();
                    sc.nextLine();

                    if (searchChoice == 1) {
                        System.out.print("Enter Customer Name: ");
                        String searchName = sc.nextLine();
                        system.searchByCustomer(searchName);
                    } else if (searchChoice == 2) {
                        System.out.print("Enter Table Number: ");
                        int searchTable = sc.nextInt();
                        system.searchByTable(searchTable);
                    } else {
                        System.out.println("Invalid option.");
                    }
                    break;

                case 5:
                    System.out.println("Exiting... Goodbye!");
                    sc.close();
                    System.exit(0);

                default:
                    System.out.println("Invalid choice, try again.");
            }
        }
    }
}